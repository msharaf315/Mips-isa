package memory;

public class MemoryFile {

	
	public String ReadAddress (int address,Memory m){
		  String x = m.getBlock(address).getValue();
		  return x;
	}
	
	public void WriteAddress (int address,Memory m,String storingDestination,Registers r){
		
		int storingRegisterNumberInt = Integer.parseInt(storingDestination, 2);
        String storingRegisterValue= r.getRegisters(storingRegisterNumberInt).getValue();
		
		 m.getBlock(address).setValue(storingRegisterValue);
		
		
	}
}

package memory;

import ALU.ALU;
public class RegisterFile {
	String StoringDestination;
	//
    //r.getRegisters(storingDestinationInt).setValue(Integer.toBinaryString(x));
	
	public void getRegisters(String opcode,String storingDestination,String firstRegisterNumber,String secondRegisterNumber,Memory m,Registers r,ALU a,RegisterFile regFile){
    	int firstRegisterNumberInt = Integer.parseInt(firstRegisterNumber, 2);
    	String r1=r.getRegisters(firstRegisterNumberInt).getValue();
        int secondRegisterNumberInt = Integer.parseInt(secondRegisterNumber, 2);
        String r2= r.getRegisters(secondRegisterNumberInt).getValue();
        a.operate(opcode,storingDestination,r1,r2,r,m,regFile);
        
    	
	}
	public void getRegistersImmediate(String opcode,String storingDestination,String firstRegisterNumber,Memory m,Registers r,ALU a,RegisterFile regFile){
    	int firstRegisterNumberInt = Integer.parseInt(firstRegisterNumber, 2);
        String r1 = r.getRegisters(firstRegisterNumberInt).getValue();
      
        
        a.operate(opcode,storingDestination,r1,a.getImmediateValue(),r,m,regFile);
     
	}
	
	public int getRegister4memory(String opcode,String storingDestination,String firstRegisterNumber,Memory m,Registers r){
		int firstRegisterNumberInt = Integer.parseInt(firstRegisterNumber, 2);
    	String r1=r.getRegisters(firstRegisterNumberInt).getValue();
    	int x = Integer.parseInt(r1);
    	return x;
	}
	
	
   public void store(String storingDestination,String value,Registers r){
	   int storingDestinationInt = Integer.parseInt(storingDestination,2);
	   r.getRegisters(storingDestinationInt).setValue(value);
   }
}

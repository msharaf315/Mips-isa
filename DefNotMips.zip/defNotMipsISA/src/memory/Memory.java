package memory;

import java.util.ArrayList;

public class Memory {
	private static int size;// size of the memory
	private static Block[] memory;// a memory of Blocks

	public  float utilization() {
			return (size - getFreeSpace()) / size;
	}

	// initializes a new memory with specified size
	public Memory() {
		Memory.size = 128;
		memory = new Block[size];
		for (int i = 0; i < memory.length; i++) {
			memory[i] = new Block();
		}
	}

	public static Block[] getMemory() {
		return memory;
	}


	// returns the size of the memory
	public static int getSize() {
		return size;
	}

	// sets the size of the memory
	public static void setSize(int size) {
		Memory.size = size;
	}


	// returns a Block given a specific location
	public Block getBlock(int location) {
		return memory[location];
	}

	// deletes a Block given a specific location
	public void deletebylocation(int location) {
		memory[location].delete();
	}

	// clears the memory
	public void clear() {
		for (Block block : memory) {
			block.delete();
		}
	}

	public String toString() {
		ArrayList<String> s = null;
		for (int i = 0; i < memory.length; i++) {
			Block b = this.getBlock(i);
			if(!b.isEmpty()){
				s.add("in memory location "+i+" the value is " + b.getValue());
			}
		}		
		return s.toString();
}

	// get the free space of the memory as number of empty Blocks
	public static int getFreeSpace() {
		int i = 0;
		for (Block block : memory) {
			if (block.isEmpty())
				i++;
		}
		return i;

	}

	public static void main(String[] args) {

	}
}
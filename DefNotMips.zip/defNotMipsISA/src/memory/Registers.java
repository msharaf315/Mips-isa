package memory;

import java.util.ArrayList;

public class Registers {
	private static int size=32;// size of the registers
	private static Block[] registers;// a registers of Blocks
	public  float utilization() {
			return (size - getFreeSpace()) / size;
	}

	// initializes a new registers with specified size
	public Registers() {
		Registers.size = 32;
		registers = new Block[size];
		for (int i = 0; i < registers.length; i++) {
			switch(i){
		       case 0:{
		    	   registers[i] = new Block("ZEROS","00000000000000000000000000000000");
		    	   break;
		        }
		       case 1:{

		    	   registers[i] = new Block("ZEROS","11111111111111111111111111111111");
		    	   break;
		       }
		       case 2:{

		    	   registers[i] = new Block("pc");
		    	   break;
		       }
		       case 3:{

		    	   registers[i] = new Block("ZERO","00000000000000000000000000000000");
		    	   break;
		       }
		       case 4:{

		    	   registers[i] = new Block("ONE","00000000000000000000000000000001");
		    	   break;
		       }
		       case 5:{

		    	   registers[i] = new Block("REG0");
		    	   break;
		       }
		       case 6:{

		    	   registers[i] = new Block("REG1");
		    	   break;
		       }
		       case 7:{

		    	   registers[i] = new Block("REG2");
		    	   break;
		       }
		       case 8:{

		    	   registers[i] = new Block("REG3");
		    	   break;
		       }
		       case 9:{

		    	   registers[i] = new Block("REG4");
		    	   break;
		       }
		       case 10:{

		    	   registers[i] = new Block("REG5");
		    	   break;
		       }
		       case 11:{

		    	   registers[i] = new Block("REG6");
		    	   break;
		       }
		       case 12:{

		    	   registers[i] = new Block("REG7");
		    	   break;
		       }
		       case 13:{

		    	   registers[i] = new Block("REG8");
		    	   break;
		       }
		       case 14:{

		    	   registers[i] = new Block("REG9");
		    	   break;
		       }
		       case 15:{

		    	   registers[i] = new Block("REG10");
		    	   break;
		       }
		       case 16:{

		    	   registers[i] = new Block("REG11");
		    	   break;
		       }
		       case 17:{

		    	   registers[i] = new Block("REG12");
		    	   break;
		       }
		       case 18:{

		    	   registers[i] = new Block("REG13");
		    	   break;
		       }
		       case 19:{

		    	   registers[i] = new Block("REG14");
		    	   break;
		       }
		       case 20 :{

		    	   registers[i] = new Block("REG15");
		    	   break;
		       }
		       case 21 :{

		    	   registers[i] = new Block("REG16");
		    	   break;
		       }
		       case 22:{

		    	   registers[i] = new Block("REG17");
		    	   break;
		       }
		       case 23:{

		    	   registers[i] = new Block("REG18");
		    	   break;
		       }
		       case 24:{

		    	   registers[i] = new Block("REG19");
		    	   break;
		       }
		       case 25:{

		    	   registers[i] = new Block("ARG0");
		    	   break;
		       }
		       case 26:{

		    	   registers[i] = new Block("ARG1");
		    	   break;
		       }
		       case 27:{

		    	   registers[i] = new Block("ARG2");
		    	   break;
		       }
		       case 28:{

		    	   registers[i] = new Block("ARG3");
		    	   break;
		       }
		       case 29:{

		    	   registers[i] = new Block("RET0");
		    	   break;
		       }
		       case 30:{

		    	   registers[i] = new Block("RET1");
		    	   break;
		       }
		       case 31:{

		    	   registers[i] = new Block("RA");
		    	   break;
		       }
		 
		         }
		
		
		
		}
	}

	public  Block getRegisters(int index) {
		return this.registers[index];
	}


	// returns the size of the registers
	public static int getSize() {
		return size;
	}

	// sets the size of the registers
	public static void setSize(int size) {
		Registers.size = size;
	}


	// returns a Block given a specific location
	public Block getBlock(int location) {
		return registers[location];
	}

	// deletes a Block given a specific location
	public void deletebylocation(int location) {
		registers[location].delete();
	}

	// clears the registers
	public void clear() {
		for (Block block : registers) {
			block.delete();
		}
	}

	public String toString() {
		ArrayList<String> s = null;
		for (int i = 0; i < registers.length; i++) {
			Block b = this.getBlock(i);
			if(!b.isEmpty()){
				s.add("in registers location "+i+" the value is " + b.getValue());
			}
		}		
		return s.toString();
}

	// get the free space of the registers as number of empty Blocks
	public static int getFreeSpace() {
		int i = 0;
		for (Block block : registers) {
			if (block.isEmpty())
				i++;
		}
		return i;

	}

	public static void main(String[] args) {

	}
}
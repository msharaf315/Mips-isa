package memory;

public class Block {
	String value;
    int blockSize=32;
    public String name;
	
	//checks whether if the word is empty or not
	public boolean isEmpty() {
		if (value.isEmpty())
			return true;
		else
			return false;
	}


	public Block() {
		this.value = "";
	}
	public Block(String name) {
		this.value ="";
		this.name = name;
	}
	public Block(String name, String value) {
		this.value =value;
		this.name = name;
	}


	public String getValue() {
		return value;
	}

	public void setValue(String value) {
	     this.value = (value.length()<=this.blockSize) ? value:this.value; 
	}

	public void insert(String value) {
		this.value = value;
	}

	public void delete() {
	this.value="";
	}

	public int toInt() {
		int valueInInt;
		valueInInt = Integer.parseInt(this.value, 2);
		return valueInInt;
	}
}
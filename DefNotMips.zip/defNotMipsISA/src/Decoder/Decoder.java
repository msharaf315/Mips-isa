package Decoder;

import defNotMipsISA.IsaCompiler;
import ALU.ALU;
import memory.Memory;
import memory.MemoryFile;
import memory.RegisterFile;
import memory.Registers;
import singExtender.SignExtender;

public class Decoder {
	public  boolean fetchDeckFlag=false;
	
  
	
//	static int comp = 1 ; 

	public void Decode(String input,ALU a,Memory m, Registers r,RegisterFile regFile,SignExtender SignExtend,MemoryFile memfile){
		this.fetchDeckFlag=true;
        String opcode = input.substring(0,5);
        System.out.println("opcode is "+opcode);
        int instruction = Integer.parseInt(opcode, 2);
        System.out.println("im starting the decoding");
        switch(instruction){
       case 0:{
    	//SUB
    	   System.out.println("SUB IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String secondRegisterNumber = input.substring(15,20);
         regFile.getRegisters(opcode,storingDestination,firstRegisterNumber,secondRegisterNumber,m,r,a,regFile);  
         break;   
        }
       case 1:{
    	//SUBI
    	   System.out.println("SUBI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   SignExtend.Extend(immediateValue,a);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);
           break;
          
         }
       case 2:{
    	   //ADD
    	   System.out.println("ADD IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String secondRegisterNumber = input.substring(15,20);
         regFile.getRegisters(opcode,storingDestination,firstRegisterNumber,secondRegisterNumber,m,r,a,regFile);  
    	   break;
       }
       case 3:{
    	 //MUL
    	   System.out.println("MUL IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String secondRegisterNumber = input.substring(15,20);
         regFile.getRegisters(opcode,storingDestination,firstRegisterNumber,secondRegisterNumber,m,r,a,regFile);  
    	   break;
          
            }
       case 4:{
    	   //DIV
    	   System.out.println("DIV IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String secondRegisterNumber = input.substring(15,20);
         regFile.getRegisters(opcode,storingDestination,firstRegisterNumber,secondRegisterNumber,m,r,a,regFile);  
    	   break;
             }
       case 5:{
    	   //ADDI
    	   System.out.println("ADDI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   SignExtend.Extend(immediateValue,a);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);
           break;
           
       }
       case 6:{
    	   //MULI
    	   System.out.println("MULI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);
           break;
           
      }
       case 7:{
    	   //DIVI
    	   System.out.println("DIVI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   SignExtend.Extend(immediateValue,a);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);
           break;
           }
       case 8:{
    	   //AND
    	   System.out.println("AND IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String secondRegisterNumber = input.substring(15,20);
         regFile.getRegisters(opcode,storingDestination,firstRegisterNumber,secondRegisterNumber,m,r,a,regFile); 
    	   break;
       }
       case 9:{
           //OR
    	   System.out.println("OR IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String secondRegisterNumber = input.substring(15,20);
         regFile.getRegisters(opcode,storingDestination,firstRegisterNumber,secondRegisterNumber,m,r,a,regFile); 
    	   break;
       }
       case 10:{
           //XOR
    	   System.out.println("XOR IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String secondRegisterNumber = input.substring(15,20);
         regFile.getRegisters(opcode,storingDestination,firstRegisterNumber,secondRegisterNumber,m,r,a,regFile); 
    	   break;
       }
       case 11:{
           //ANDI
    	   System.out.println("ANDI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   SignExtend.Extend(immediateValue,a);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);    
    	   break;
       }
       case 12:{
           //ORI
    	   System.out.println("ORI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   SignExtend.Extend(immediateValue,a);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);    	
    	   break;
       }
       case 13:{
    	   //XORI
    	   System.out.println("XORI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   SignExtend.Extend(immediateValue,a);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);   
    	   break;
       }
       case 14:{
    	   //INV
    	   System.out.println("INV IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile); 
    	   break;
       }
       case 15:{
    	//COMP
    	   System.out.println("COMP IS EXECUTED");
    	   
    	   String rg1 = input.substring(5,10);
    	   int rgInt1 = Integer.parseInt(rg1, 2);
    	  
    	   String rg2 = input.substring(10,15);
    	   int rgInt2 = Integer.parseInt(rg2, 2);
    	   
    	   String rg3 = input.substring(15,20);
    	   int rgInt3 = Integer.parseInt(rg3, 2);
    	   
    	  // String memoryValue1 =r.getBlock(rgInt1).getValue();
    	//   int memoryValueInt1 = Integer.parseInt(memoryValue1, 2);
    	   
    	   String memoryValue2 =r.getBlock(rgInt2).getValue();
    	   int memoryValueInt2 = Integer.parseInt(memoryValue2, 2);
    	   
    	   String memoryValue3 =r.getBlock(rgInt3).getValue();
    	   int memoryValueInt3 = Integer.parseInt(memoryValue3, 2);
    	   
    	   int temp = memoryValueInt2  - memoryValueInt3 ; 
    	   memoryValue3 = Integer.toString(temp);
    	   if (temp ==0) {
    		    		   
    		   r.getBlock(rgInt1).setValue(Integer.toString(temp));
    		   
    		       		   
    	   }else {
    		   
    		   IsaCompiler.setPc(IsaCompiler.getPc()+1);
    	   }
    	     
    	  
    	   
    	   break;
    	   
       }
       case 16:{
           //SHL
    	   System.out.println("SHL IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);
    	   break;
       }
       case 17:{
           //SHR
    	   System.out.println("SHR IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   regFile.getRegistersImmediate(opcode,storingDestination,firstRegisterNumber,m,r,a,regFile);
    	   break;
       }
       case 18:{
           
    	   break;
       }
       case 19:{
           
    	   break;
       }
       case 20 :{
    	   //JREG
    	   
    	   
    	   
//    	   if(comp==1) {
    	   String jumpingDestination = input.substring(5,10);
    	   int jumpingDestinationInt = Integer.parseInt(jumpingDestination, 2);
           
    	   String memoryValue =r.getBlock(jumpingDestinationInt).getValue();
    	   int memoryValueInt = Integer.parseInt(memoryValue, 2);
    	   IsaCompiler.setPc(memoryValueInt-1);
//    	   }
    	   
//    	   comp=1 ;
    	   break;
       }
       case 21 :{
           //JNEG
    	   
    	   break;
       }
       case 22 :{
           //JPOS
    	   
    	   break;
       }
       case 23:{
    	  //JLAB
    	   
    	   break;
       }
       case 24:{
    	   //READ
    	   System.out.println("READ IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   String offset = immediateValue;
    	   SignExtend.Extend4Memory(offset);
    	   int offsetint=Integer.parseInt(offset);
    	   int address = regFile.getRegister4memory(opcode, storingDestination, firstRegisterNumber, m, r);
    	   int x=offsetint  + address;
    	   regFile.store(storingDestination,memfile.ReadAddress(x, m) , r);
    	   
           break;
       }
       case 25:{
    	   //WRT
    	   System.out.println("WRITE IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String firstRegisterNumber = input.substring(10,15);
    	   String immediateValue = input.substring(15,32);
    	   SignExtend.Extend4Memory(immediateValue);
    	   int offsetInt = Integer.parseInt(immediateValue);
    	   int address = regFile.getRegister4memory(opcode, storingDestination, firstRegisterNumber, m, r);
    	   int x = address + offsetInt ; 
    	   
    	   memfile.WriteAddress(x, m,storingDestination,r);
    	   
           
    	   break;
       }
       case 26:{
    	   //READI
    	   System.out.println("READI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String immediateValue = input.substring(10,32);
    	   SignExtend.Extend4Memory(immediateValue);
    	   int address =Integer.parseInt(immediateValue);
    	   regFile.store(storingDestination,memfile.ReadAddress(address, m) , r);
    	   
    	   break;
    	   
       }
       case 27:{
           //WRTI
    	   System.out.println("WRTI IS EXECUTED");
    	   String storingDestination = input.substring(5,10);
    	   String immediateValue = input.substring(10,32);
    	   SignExtend.Extend4Memory(immediateValue);
    	   memfile.WriteAddress( Integer.parseInt(immediateValue), m,storingDestination,r);
    	   
    	   break;
       }
       
         }
        System.out.println("i finished decoding an instruction");
        this.fetchDeckFlag=false;
	}
	
}

package ALU;

import memory.Memory;
import memory.RegisterFile;
import memory.Registers;
import singExtender.SignExtender;

public class ALU {
	
	 public String getImmediateValue() {
		return immediateValue;
	}


	public void setImmediateValue(String immediateValue) {
		this.immediateValue = immediateValue;
	}


	String immediateValue ;  
	
	
public void operate (String opcode,String storingDestination,String r1,String r2,Registers r,Memory m ,RegisterFile regfile ){
	int instruction = Integer.parseInt(opcode, 2);
    
	
	
    switch(instruction){
case 0:{
	//SUB
      
       int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
       int x =  firstRegisterValueInt - secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
       break;   
    	
}
   case 1:{
	//SUBI
	   
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt - secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);

       break;
      
     }
    case 2:{
	   //ADD
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
       int x =  firstRegisterValueInt + secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
	   break;
   }
   case 3:{
	 //MUL
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
       int x =  firstRegisterValueInt * secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
      
	   break;
      
        }
   case 4:{
	   //DIV
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
       int x =  firstRegisterValueInt / secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
	   break;
         }
   case 5:{
	   //ADDI
	 
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt + secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
       
       break;
       
   }
   case 6:{
	   //MULI
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt * secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
       
 
       break;
       
  }
   case 7:{
	   //DIVI
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt / secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
       
       break;
       }
   case 8:{
	 //AND
	  int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
       int x =  firstRegisterValueInt & secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
	   break;
   }
   case 9:{
	 //OR
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
       int x =  firstRegisterValueInt | secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
	   break;
   }
   case 10:{
	   //XOR
	  int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
       int x =  firstRegisterValueInt ^ secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
	   break;
   }
   case 11:{
	   //ANDI
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt & secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
       
       break ; 
   }
   case 12:{
	   //ORI
	   
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt | secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
       
	   break;
   }
   case 13:{
	   //XORI
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt ^ secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
       break;
   }
   case 14:{
	   //INV
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
	  String x = Integer.toString(firstRegisterValueInt);
	    x = x.replaceAll("0", "x").replaceAll("1", "0").replaceAll("x", "1");    	   
	    regfile.store(storingDestination,x,r);
      
	   break;
   }
   case 15:{
	
	   break;
   }
   case 16:{
	 //SHL
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt << secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
     
      
	   break;
   }                         
   case 17:{
	   //SHR
	   
	   int firstRegisterValueInt = Integer.parseInt(r1,2);
       int secondRegisterValueInt = Integer.parseInt(r2,2);
      
       int x =  firstRegisterValueInt   >> secondRegisterValueInt ;
       regfile.store(storingDestination,Integer.toBinaryString(x),r);
     
      
	   break;
	   
   }
   case 18:{
       
	   break;
   }
   case 19:{
       
	   break;
   }
   case 20 :{
       
	   break;
   }
   case 21 :{
       
	   break;
   }
   case 23:{
	  
	   break;
   }
   case 24:{
	 
       break;
   }
   case 25:{
	   
       
	   break;
   }
   case 26:{

	   
	   break;
	   
   }
   case 27:{
       
	   
	   break;
   }
   
     }
}

    
}
//	


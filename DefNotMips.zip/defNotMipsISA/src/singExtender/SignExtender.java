package singExtender;

import ALU.ALU;
import memory.Memory;
import memory.RegisterFile;
import memory.Registers;

public class SignExtender {

	
	public void Extend(String input,ALU a){
	
		for (int i = 32-input.length() ; i>0 ;i--  ) {
			
			input= "0" + input ;
			
		}
		
		
		a.setImmediateValue(input);
		
		
		
	}
	public void Extend4Memory(String input){
for (int i = 32-input.length() ; i>0 ;i--  ) {
			
			input= "0" + input ;
			
		}
	}
	
	
	
}

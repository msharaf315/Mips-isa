package defNotMipsISA;



public class MachineLanguagetoCode {
	static String[] bin = new String[28];
	static String[] instruction = new String[28];
	static String[] binr = new String[33];
	static String[]registers = new String[33];
	public MachineLanguagetoCode() {		
		bin[0] = "00000";
		bin[1] = "00001";
		bin[2] = "00010";
		bin[3] = "00011";
		bin[4] = "00100";
		bin[5] = "00101";
		bin[6] = "00110";
		bin[7] = "00111";
		bin[8] = "01000";
		bin[9] = "01001";
		bin[10] = "01010";
		bin[11] = "01011";
		bin[12] = "01100";
		bin[13] = "01101";
		bin[14] = "01110";
		bin[15] = "01111";
		bin[16] = "10000";
		bin[17] = "11001";
		bin[18] = "10010";
		bin[19] = "10011";
		bin[20] = "10100";
		bin[21] = "10101";
		bin[22] = "10110";
		bin[23] = "10111";
		bin[24] = "11000";
		bin[25] = "11001";
		bin[26] = "11010";
		bin[27] = "11011";
		
		instruction[0] = "SUB";
		instruction[1] = "SUBI";
		instruction[2] = "ADD";
		instruction[3] = "MUL";
		instruction[4] = "DIV";
		instruction[5] = "ADDI";
		instruction[6] = "MULI";
		instruction[7] = "DIVI";
		instruction[8] = "AND";
		instruction[9] = "OR";
		instruction[10] = "XOR";
		instruction[11] = "ANDI";
		instruction[12] = "ORI";
		instruction[13] = "XORI";
		instruction[14] = "INV";
		instruction[15] = "COMP";
		instruction[16] = "SHL";
		instruction[17] = "SHR";
		instruction[18] = "LSL";
		instruction[19] = "LSR";
		instruction[20] = "JREG";
		instruction[21] = "JNEG";
		instruction[22] = "JPOS";
		instruction[23] = "JLAB";
		instruction[24] = "READ";
		instruction[25] = "WRT";
		instruction[26] = "READI";
		instruction[27] = "WRTI";
		
		binr[0] ="00000";
		binr[1] ="00001";
		binr[2] ="00010";
		binr[3] ="00011";
		binr[4] ="00100";
		binr[5] ="00101";
		binr[6] ="00110";
		binr[7] ="00111";
		binr[8] ="01000";
		binr[9] ="01001";
		binr[10] ="01010";
		binr[11] ="01011";
		binr[12] ="01100";
		binr[13] ="01101";
		binr[14] ="01110";
		binr[15] ="01111";
		binr[16] ="10000";
		binr[17] ="10001";
		binr[18] ="10010";
		binr[19] ="10011";
		binr[20] ="10100";
		binr[21] ="10101";
		binr[22] ="10110";
		binr[23] ="10111";
		binr[24] ="11000";
		binr[25] ="11001";
		binr[26] ="11010";
		binr[27] ="11011";
		binr[28] ="11100";
		binr[29] ="11101";
		binr[30] ="11110";
		binr[31] ="11111";
		
		
		registers[0] = "ZEROS";
		registers[1] = "ONES";
		registers[2] = "PC";
		registers[3] = "ZERO";
		registers[4] = "ONE";
		registers[5] = "REG0";
		registers[6] = "REG1";
		registers[7] = "REG2";
		registers[8] = "REG3";
		registers[9] = "REG4";
		registers[10] = "REG5";
		registers[11] = "REG6";
		registers[12] = "REG7";
		registers[13] = "REG8";
		registers[14] = "REG9";
		registers[15] = "REG10";
		registers[16] = "REG11";
		registers[17] = "REG12";
		registers[18] = "REG13";
		registers[19] = "REG14";
		registers[20] = "REG15";
		registers[21] = "REG16";
		registers[22] = "REG17";
		registers[23] = "REG18";
		registers[24] = "REG19";
		registers[25] = "ARG0";
		registers[26] = "ARG1";
		registers[27] = "ARG2";
		registers[28] = "ARG3";
		registers[29] = "RET0";
		registers[30] = "RET1";
		registers[31] = "RA";




}
	public static String getInstruction(String instructionn) {
		for(int i=0;i<instruction.length;i++) {
			if(instruction[i].equalsIgnoreCase(instructionn)) {
				return bin[i];
			}	
		}
		throw new IllegalArgumentException("Invalid Instruction");
	}
	public static String getRegister(String register) {
		for(int i=0;i<registers.length;i++) {
			if(registers[i].equalsIgnoreCase(register)) {
				return binr[i];
			}
		}
		throw new IllegalArgumentException("Invalid Register");
	}
}

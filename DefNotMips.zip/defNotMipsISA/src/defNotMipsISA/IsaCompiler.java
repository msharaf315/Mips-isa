package defNotMipsISA;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

import javax.swing.JComboBox;
import javax.swing.JFrame;

import ALU.ALU;
import Decoder.Decoder;
import memory.Memory;
import memory.MemoryFile;
import memory.RegisterFile;
import memory.Registers;
import singExtender.SignExtender;

public class IsaCompiler {
	static MainWindow window;
	static String[] splitter(String input){
		String[] instructions = input.split(",");
		return instructions;
	}
	static int pc=0;
	public static boolean memoryFlag=false;
	public static boolean executionFlag=false;
	public static boolean writeBackFlag=false;
	
	public static void setPc(int newPc) {
		pc = newPc;
	}
	public static int getPc() {
		return pc;
	}

	
	public static String settingImmediate(String immediate) {
		int length = immediate.length();
		String zeroes = "";
		for(int i=0;i<17-length;i++) {
			zeroes = zeroes + "0";
		}
		return (zeroes + immediate);
	}

	
	
	public static void main(String[] args) throws IOException{
	    //intializse memory and registers and the decoder
		window =new MainWindow();
		window.setVisible(true);
		Memory m = new Memory();
	    Registers r = new Registers();
	    MemoryFile memfile = new MemoryFile();
	    Decoder decoder = new Decoder();
	    ALU alu = new ALU();
	    RegisterFile regfile = new RegisterFile();
	    SignExtender SignExtend =new SignExtender() ; 
	    window.btnRun.addActionListener(new ActionListener() {    //Run Button Action Listener 
	    	  public void actionPerformed(ActionEvent e) { 
	    		 
	    		  String line = window.textField.getText();
	    		  System.out.println(line);
	    		  String[] instructions = line.split("\\r?\\n");
	    		  for(int j = 0;j<instructions.length;j++) {
	    			  StringTokenizer st = new StringTokenizer(instructions[j]);  
	    		  int i =0;
	    		  String operation ="";
	    		  while(true) {
	    			  if(instructions[j].charAt(i)==',') {
	    				  break;
	    			  }
	    			  else {
	    				  operation = operation+instructions[j].charAt(i);
	    			  }
	    			  i++;
	    		  }
	    		  System.out.println(operation);
	    		  //System.out.println(reg1);
	    		  //System.out.println(reg2);
	    		  
	    		  new MachineLanguagetoCode();
	    		  String total = null;
	    		  switch(operation) {
	    		  case "ADDI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
	    			 String ins= MachineLanguagetoCode.getInstruction(operation);
		    		 String regg1 = MachineLanguagetoCode.getRegister(reg1);
		    		 String regg2 = MachineLanguagetoCode.getRegister(reg2);
		    		 String imm = st.nextToken();
		    		 //String imm = settingImmediate(reg2);
		    		 //System.out.println("55555555555");
		    		 System.out.println(reg2);
		    		 System.out.println(operation);
		    		 total = ins+regg1+regg2+imm;
		    		 break;
	    		  }
	    		  case "SUBI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
			    		 String regg1 = MachineLanguagetoCode.getRegister(reg1);
			    		 String regg2 = MachineLanguagetoCode.getRegister(reg2);
			    		 String imm = st.nextToken();
			    		 //String imm = settingImmediate(reg2);
			    		 //System.out.println("55555555555");
			    		 System.out.println(reg2);
			    		 System.out.println(operation);
			    		 total = ins+regg1+regg2+imm;
			    		     break;
	    		  }
	    		  case "MULI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
			    		 String regg1 = MachineLanguagetoCode.getRegister(reg1);
			    		 String regg2 = MachineLanguagetoCode.getRegister(reg2);
			    		 String imm = st.nextToken();
			    		 //String imm = settingImmediate(reg2);
			    		 //System.out.println("55555555555");
			    		 System.out.println(reg2);
			    		 System.out.println(operation);
			    		 total = ins+regg1+regg2+imm;
			    		   break;
	    		  }
	    		  case "DIVI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
			    		 String regg1 = MachineLanguagetoCode.getRegister(reg1);
			    		 String regg2 = MachineLanguagetoCode.getRegister(reg2);
			    		 String imm = st.nextToken();
			    		 //String imm = settingImmediate(reg2);
			    		 //System.out.println("55555555555");
			    		 System.out.println(reg2);
			    		 System.out.println(operation);
			    		 total = ins+regg1+regg2+imm;
			    		 
	    			  break;
	    		  }
	    		  case "ANDI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
			    		 String regg1 = MachineLanguagetoCode.getRegister(reg1);
			    		 String regg2 = MachineLanguagetoCode.getRegister(reg2);
			    		 String imm = st.nextToken();
			    		 //String imm = settingImmediate(reg2);
			    		 //System.out.println("55555555555");
			    		 System.out.println(reg2);
			    		 System.out.println(operation);
			    		 total = ins+regg1+regg2+imm;
			    		 
	    			  break;
	    		  }
	    		  case "ORI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
			    		 String regg1 = MachineLanguagetoCode.getRegister(reg1);
			    		 String regg2 = MachineLanguagetoCode.getRegister(reg2);
			    		 String imm = st.nextToken();
			    		 //String imm = settingImmediate(reg2);
			    		 //System.out.println("55555555555");
			    		 System.out.println(reg2);
			    		 System.out.println(operation);
			    		 total = ins+regg1+regg2+imm;
			    		   break;
	    		  }
	    		  case "XORI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
			    		 String regg1 = MachineLanguagetoCode.getRegister(reg1);
			    		 String regg2 = MachineLanguagetoCode.getRegister(reg2);
			    		 String imm = st.nextToken();
			    		 //String imm = settingImmediate(reg2);
			    		 //System.out.println("55555555555");
			    		 System.out.println(reg2);
			    		 System.out.println(operation);
			    		 total = ins+regg1+regg2+imm;
			    		 
	    			  break;
	    		  }
	    		  case "COMP":{ 
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  String regg2 = MachineLanguagetoCode.getRegister(reg2);
	    			  String regg3 = MachineLanguagetoCode.getRegister(st.nextToken());
	    			  total = ins+regg1+regg2+regg3+"000000000000";
	    			  break;
	    		  }
	    		  
	    		  
	    		  case "JREG":{ //NOT COMPLETE
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  //String reg2 = st.nextToken(",");
		    		  //j=pc;
	    			  String ins = MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  total = ins+regg1+0000000000000000000000;
	    			  break;
	    		  }
	    		  case "READI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins = MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  System.out.println(ins);
	    			  System.out.println(regg1);
	    			  System.out.println(reg2);
	    			  SignExtend.Extend4Memory(reg2);
	    			  System.out.println(reg2);
	    			  total = ins+regg1+reg2;
	    			  
	    			  
	    			  break;
	    		  }
	    		  case "WRTI":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins = MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  SignExtend.Extend4Memory(reg2);
	    			  total = ins+regg1+reg2;
	    			  break;
	    		  }
	    		  case "ADD":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
		    		  String regg1 = MachineLanguagetoCode.getRegister(reg1);
		    		  String regg2 = MachineLanguagetoCode.getRegister(reg2);
		    		  String reg3 = st.nextToken();
		    		  String regg3 = MachineLanguagetoCode.getRegister(reg3);
		    		  System.out.println(ins);
		    		  System.out.println(regg1);
		    		  System.out.println(regg2);
	    			  total = ins+regg1+regg2+regg3+"000000000000"; //Adding the remaining bits to complete 32 bits not working with immediate values  
	    			  break;
	    		  }
	    		  case "AND":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
		    		  String regg1 = MachineLanguagetoCode.getRegister(reg1);
		    		  String regg2 = MachineLanguagetoCode.getRegister(reg2);
		    		  String reg3 = st.nextToken();
		    		  String regg3 = MachineLanguagetoCode.getRegister(reg3);
		    		  System.out.println(ins);
		    		  System.out.println(regg1);
		    		  System.out.println(regg2);
	    			  total = ins+regg1+regg2+regg3+"000000000000"; //Adding the remaining bits to complete 32 bits not working with immediate values  
	    			  break;
	    		  }
	    		  case "SUB":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
		    		  String regg1 = MachineLanguagetoCode.getRegister(reg1);
		    		  String regg2 = MachineLanguagetoCode.getRegister(reg2);
		    		  String reg3 = st.nextToken();
		    		  String regg3 = MachineLanguagetoCode.getRegister(reg3);
		    		  System.out.println(ins);
		    		  System.out.println(regg1);
		    		  System.out.println(regg2);
	    			  total = ins+regg1+regg2+regg3+"000000000000"; //Adding the remaining bits to complete 32 bits not working with immediate values  
	    			  break;
	    		  }
	    		  case "MUL":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
		    		  String regg1 = MachineLanguagetoCode.getRegister(reg1);
		    		  String regg2 = MachineLanguagetoCode.getRegister(reg2);
		    		  String reg3 = st.nextToken();
		    		  String regg3 = MachineLanguagetoCode.getRegister(reg3);
		    		  System.out.println(ins);
		    		  System.out.println(regg1);
		    		  System.out.println(regg2);
	    			  total = ins+regg1+regg2+regg3+"000000000000"; //Adding the remaining bits to complete 32 bits not working with immediate values  
	    			  break;
	    		  }
	    		  case "DIV":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
		    		  String regg1 = MachineLanguagetoCode.getRegister(reg1);
		    		  String regg2 = MachineLanguagetoCode.getRegister(reg2);
		    		  String reg3 = st.nextToken();
		    		  String regg3 = MachineLanguagetoCode.getRegister(reg3);
		    		  System.out.println(ins);
		    		  System.out.println(regg1);
		    		  System.out.println(regg2);
	    			  total = ins+regg1+regg2+regg3+"000000000000"; //Adding the remaining bits to complete 32 bits not working with immediate values  
	    			  break;
	    		  }
	    		  case "OR":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
		    		  String regg1 = MachineLanguagetoCode.getRegister(reg1);
		    		  String regg2 = MachineLanguagetoCode.getRegister(reg2);
		    		  String reg3 = st.nextToken();
		    		  String regg3 = MachineLanguagetoCode.getRegister(reg3);
		    		  System.out.println(ins);
		    		  System.out.println(regg1);
		    		  System.out.println(regg2);
	    			  total = ins+regg1+regg2+regg3+"000000000000"; //Adding the remaining bits to complete 32 bits not working with immediate values  
	    			    break;
	    		  }
	    		  case "XOR":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins= MachineLanguagetoCode.getInstruction(operation);
		    		  String regg1 = MachineLanguagetoCode.getRegister(reg1);
		    		  String regg2 = MachineLanguagetoCode.getRegister(reg2);
		    		  String reg3 = st.nextToken();
		    		  String regg3 = MachineLanguagetoCode.getRegister(reg3);
		    		  System.out.println(ins);
		    		  System.out.println(regg1);
		    		  System.out.println(regg2);
	    			  total = ins+regg1+regg2+regg3+"000000000000"; //Adding the remaining bits to complete 32 bits not working with immediate values  
	    			  break;
	    		  }
	    		  case "INV":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins = MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  String regg2 = MachineLanguagetoCode.getRegister(reg2);
	    			  System.out.println(ins);
		    		  System.out.println(regg1);
		    		  System.out.println(regg2);
		    		  total = ins+regg1+regg2+"00000000000000000";
		    		  break;
	    		  }
	    		  case "SHL":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins = MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  String regg2 = MachineLanguagetoCode.getRegister(reg2);
	    			  String imm = st.nextToken();
	    			  total = ins+regg1+regg2+imm;
	    			  break;
	    		  }
	    		  case "SHR":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins = MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  String regg2 = MachineLanguagetoCode.getRegister(reg2);
	    			  String imm = st.nextToken();
	    			  total = ins+regg1+regg2+imm;
	    			  break;
	    		  }
	    		  case "READ":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins = MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  String regg2 = MachineLanguagetoCode.getRegister(reg2);
	    			  String imm = st.nextToken();
	    			  total = ins+regg1+regg2+imm;
	    			  break;
	    		  }
	    		  case "WRT":{
	    			  String BAD1 = st.nextToken(",");
		    		  String reg1 = st.nextToken(",");
		    		  String reg2 = st.nextToken(",");
		    		  
	    			  String ins = MachineLanguagetoCode.getInstruction(operation);
	    			  String regg1 = MachineLanguagetoCode.getRegister(reg1);
	    			  String regg2 = MachineLanguagetoCode.getRegister(reg2);
	    			  String imm = st.nextToken();
	    			  total = ins+regg1+regg2+imm;
	    			  break;
	    		  }

	    		  }
	    		  
	    		  System.out.println(total);
	    		  System.out.println(total.length());
	    		    //main method
	    		    //for(int j=0;i<instructions.length;j++){
	    		    	//decoder.Decode(instructions[i],alu,m,r);
	    		  		System.out.println(total + j+" da code el comp");
	    		    	decoder.Decode(total, alu, m, r,regfile,SignExtend,memfile);
	    		    	if(operation.equals("JREG")) {
	    		    		j=pc;
	    		    		window.textAreaPC.append(pc+"");
	    		    	}
	    		    	else {
	    		    	pc++;
	    		    	
	    		    	}
	    		    	window.textAreaPC.setText("");
	    		    	window.textAreaPC.append(pc+"");
	    		    	
	    		    	
	    		    //}
	    		    	
	    		  }
	    		}
	    	  } 
	    	 );
	    window.comboBox.addActionListener(new ActionListener() { 
	    	  public void actionPerformed(ActionEvent e) { 
	    		  @SuppressWarnings("unchecked")
				JComboBox<String> combo = (JComboBox<String>) e.getSource();
	    	        String selectedRegister = (String) combo.getSelectedItem();
	    	        window.textAreaREG.setText("");
	    	       
	    	        if (selectedRegister.equals("REG0")) {
	    	            window.textAreaREG.append(r.getBlock(5).getValue());
	    	        }
	    	        if (selectedRegister.equals("REG1")) {
	    	        	//r.getBlock(6).setValue("11111111011111111111111111111111");
		    	        window.textAreaREG.append(r.getBlock(6).getValue());
		    	            } 	    		
	    	        if (selectedRegister.equals("REG2")) {
		    	        window.textAreaREG.append(r.getBlock(7).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG3")) {
		    	        window.textAreaREG.append(r.getBlock(8).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG4")) {
		    	        window.textAreaREG.append(r.getBlock(9).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG5")) {
		    	        window.textAreaREG.append(r.getBlock(10).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG6")) {
		    	        window.textAreaREG.append(r.getBlock(11).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG7")) {
		    	        window.textAreaREG.append(r.getBlock(12).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG8")) {
		    	        window.textAreaREG.append(r.getBlock(13).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG9")) {
		    	        window.textAreaREG.append(r.getBlock(14).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG10")) {
		    	        window.textAreaREG.append(r.getBlock(15).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG11")) {
		    	        window.textAreaREG.append(r.getBlock(16).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG12")) {
		    	        window.textAreaREG.append(r.getBlock(17).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG13")) {
		    	        window.textAreaREG.append(r.getBlock(18).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG14")) {
		    	        window.textAreaREG.append(r.getBlock(19).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG15")) {
		    	        window.textAreaREG.append(r.getBlock(20).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG16")) {
		    	        window.textAreaREG.append(r.getBlock(21).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG17")) {
		    	        window.textAreaREG.append(r.getBlock(22).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG18")) {
		    	        window.textAreaREG.append(r.getBlock(23).getValue());
		    	            }
	    	        if (selectedRegister.equals("REG19")) {
		    	        window.textAreaREG.append(r.getBlock(24).getValue());
		    	            }
	    	        if (selectedRegister.equals("ARG0")) {
	    	            window.textAreaREG.append(r.getBlock(25).getValue());
	    	        }
	    	        if (selectedRegister.equals("ARG1")) {
	    	            window.textAreaREG.append(r.getBlock(26).getValue());
	    	        }
	    	        if (selectedRegister.equals("ARG2")) {
	    	            window.textAreaREG.append(r.getBlock(27).getValue());
	    	        }
	    	        if (selectedRegister.equals("ARG3")) {
	    	            window.textAreaREG.append(r.getBlock(28).getValue());
	    	        }
	    	        if (selectedRegister.equals("RET0")) {
	    	            window.textAreaREG.append(r.getBlock(29).getValue());
	    	        }
	    	        if (selectedRegister.equals("RET1")) {
	    	            window.textAreaREG.append(r.getBlock(30).getValue());
	    	        }
	    	        if (selectedRegister.equals("RA")) {
	    	            window.textAreaREG.append(r.getBlock(31).getValue());
	    	        }
	    	  } 
	    }
	    	 );
	    
	    
	    
		
	    
}}

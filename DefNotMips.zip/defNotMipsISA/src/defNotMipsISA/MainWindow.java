package defNotMipsISA;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JComboBox;
import java.awt.Font;

public class MainWindow extends JFrame {
	
	JButton btnRun;
	JPanel contentPane;
	JTextArea textField;
	JTextArea textAreaPC;
	JComboBox<String> comboBox;
	JTextArea textAreaREG;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnRun = new JButton("Run");
		btnRun.setBounds(0, 0, 64, 44);
		btnRun.setBorder(new RoundedBoarder(10));
		btnRun.setBackground(Color.GREEN);
		contentPane.add(btnRun);
		
		textField = new JTextArea();
		textField.setBounds(0, 55, 424, 131);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblPc = new JLabel("PC:");
		lblPc.setBounds(98, 14, 24, 14);
		contentPane.add(lblPc);
		
		textAreaPC = new JTextArea();
		textAreaPC.setBounds(118, 14, 49, 14);
		contentPane.add(textAreaPC);
		
		comboBox = new JComboBox();
		comboBox.setBounds(161, 197, 57, 20);
		contentPane.add(comboBox);
		comboBox.addItem("REG0");
		comboBox.addItem("REG1");
		comboBox.addItem("REG2");
		comboBox.addItem("REG3");
		comboBox.addItem("REG4");
		comboBox.addItem("REG5");
		comboBox.addItem("REG6");
		comboBox.addItem("REG7");
		comboBox.addItem("REG8");
		comboBox.addItem("REG9");
		comboBox.addItem("REG10");
		comboBox.addItem("REG11");
		comboBox.addItem("REG12");
		comboBox.addItem("REG13");
		comboBox.addItem("REG14");
		comboBox.addItem("REG15");
		comboBox.addItem("REG16");
		comboBox.addItem("REG17");
		comboBox.addItem("REG18");
		comboBox.addItem("REG19");
		comboBox.addItem("ARG0");
		comboBox.addItem("ARG1");
		comboBox.addItem("ARG2");
		comboBox.addItem("ARG3");
		comboBox.addItem("RET0");
		comboBox.addItem("RET1");
		comboBox.addItem("RA");
		
		textAreaREG = new JTextArea();
		textAreaREG.setEditable(false);
		textAreaREG.setBounds(56, 228, 368, 22);
		contentPane.add(textAreaREG);
		
		JLabel lblNewLabel = new JLabel("Result :");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(0, 231, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblMochaInstructionSet = new JLabel("Mocha Instruction Set Architecture");
		lblMochaInstructionSet.setBackground(Color.WHITE);
		lblMochaInstructionSet.setBounds(242, -1, 182, 44);
		contentPane.add(lblMochaInstructionSet);
		
			}
}
